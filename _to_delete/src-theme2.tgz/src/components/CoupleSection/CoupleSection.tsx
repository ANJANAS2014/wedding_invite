import './CoupleSection.css';
import React, { useEffect, useRef, useState } from 'react';
import { COUPLE_HOMETOWNS, WEDDING_CONTENT, WEDDING_IMAGES } from '../../data/weddingData';
import { HeaderRule } from '../shared/HeaderRule/HeaderRule';
import { NextTeaser } from '../ScrollGuide/NextTeaser';
import { burstPetals } from '../FallingPetals/FallingPetals';
import { hapticSoft } from '../../utils/haptics';
import {
  announceTeamSide,
  loadTeamSide,
  saveTeamPick,
  TEAM_CHANGE_EVENT,
  type TeamChangeDetail,
  type TeamSide,
} from '../../services/teamService';
import { PortraitRing } from './PortraitRing';
import { CoupleQuiz } from './CoupleQuiz';

interface CoupleSectionProps {
  guestName?: string;
  inviteToken?: string;
}

/** Jasmine buds strung along the garland (x as a fraction of its width; y follows the SVG curve). */
const BUDS = [0.1, 0.19, 0.28, 0.37, 0.46, 0.54, 0.63, 0.72, 0.81, 0.9];

const PERSON = {
  groom: {
    name: WEDDING_CONTENT.groom,
    role: 'The Groom',
    story: WEDDING_CONTENT.groomStory,
    img: WEDDING_IMAGES.p12,
    w: 700,
    h: 764,
    pos: '50% 25%',
    ring: 'temple' as const,
    home: COUPLE_HOMETOWNS.groom,
  },
  bride: {
    name: WEDDING_CONTENT.bride,
    role: 'The Bride',
    story: WEDDING_CONTENT.brideStory,
    img: WEDDING_IMAGES.bride_portrait,
    w: 600,
    h: 600,
    pos: '50% 50%',
    ring: 'kasavu' as const,
    home: COUPLE_HOMETOWNS.bride,
  },
};

/**
 * Bride & Groom — round portraits framed in their own heritage borders
 * (Kanjeevaram for Chennai, kasavu for Keralam), joined by a jasmine garland
 * and a hand-drawn "&". The guest's Team pick glows, with a playful
 * "Switch sides?" on the other portrait. Then the "Who's more likely to…?" game and the vows.
 */
export const CoupleSection: React.FC<CoupleSectionProps> = ({ guestName = '', inviteToken = '' }) => {
  const [side, setSide] = useState<TeamSide | null>(() => loadTeamSide());
  const picRefs = useRef<Record<TeamSide, HTMLDivElement | null>>({ groom: null, bride: null });

  useEffect(() => {
    const onChange = (e: Event) => {
      const d = (e as CustomEvent<TeamChangeDetail>).detail;
      if (d) setSide(d.side);
    };
    window.addEventListener(TEAM_CHANGE_EVENT, onChange);
    return () => window.removeEventListener(TEAM_CHANGE_EVENT, onChange);
  }, []);

  const switchTo = (next: TeamSide) => {
    setSide(next);
    hapticSoft();
    burstPetals(picRefs.current[next], 26);
    announceTeamSide({ side: next, totals: null, source: 'couple' });
    saveTeamPick(next, { inviteToken, guestName }).then(
      (totals) => totals && announceTeamSide({ side: next, totals, source: 'couple' })
    );
  };

  const renderPerson = (key: TeamSide) => {
    const p = PERSON[key];
    const mine = side === key;
    return (
      <article className={`cp-person cp-person--${key}${mine ? ' is-team' : ''}`}>
        <div className="cp-pic" ref={(el) => (picRefs.current[key] = el)}>
          <PortraitRing kind={p.ring} />
          <div className="cp-img bu">
            <img
              src={p.img}
              alt={`${p.name} portrait`}
              width={p.w}
              height={p.h}
              loading="lazy"
              decoding="async"
              style={{ objectPosition: p.pos }}
            />
          </div>
          {mine && (
            <span className="cp-badge" aria-hidden="true">
              ★ Your side
            </span>
          )}
        </div>
        <span className="cp-role">{p.role}</span>
        <h3>{p.name}</h3>
        <span className="cp-home">
          <svg viewBox="0 0 12 16" aria-hidden="true" focusable="false">
            <path d="M6 15.2S1 9.6 1 6a5 5 0 0 1 10 0c0 3.6-5 9.2-5 9.2Z" fill="none" stroke="currentColor" strokeWidth="1.2" />
            <circle cx="6" cy="6" r="1.7" fill="currentColor" />
          </svg>
          {p.home.town}
          <span className="cp-home-r"> · {p.home.region}</span>
        </span>
        <p className="cp-story">{p.story}</p>
        {side && (
          <p className="cp-team" aria-live="polite">
            {mine ? (
              <>✦ You’re on {p.name}’s side</>
            ) : (
              <button type="button" className="cp-switch" onClick={() => switchTo(key)}>
                Switch to {p.name}’s side?
              </button>
            )}
          </p>
        )}
      </article>
    );
  };

  return (
    <section className={`cp grain${side ? ` cp--team-${side}` : ''}`} id="couple" aria-labelledby="couple-title">
      <header className="cp-head reveal">
        <div className="eyebrow">The couple</div>
        <h2 id="couple-title">Bride &amp; Groom</h2>
        <HeaderRule />
      </header>

      <div className="cp-pair reveal">
        {/* Chennai ⟶ Keralam: a jasmine garland strung between the two portraits */}
        <div className="cp-garland" aria-hidden="true">
          <svg className="cp-garland-line" viewBox="0 0 100 40" preserveAspectRatio="none">
            <path d="M0 2 Q50 62 100 2" fill="none" vectorEffect="non-scaling-stroke" />
          </svg>
          {BUDS.map((x, i) => (
            <i
              key={x}
              className="cp-bud"
              style={{ left: `${x * 100}%`, top: `calc(var(--gh) * ${((2 + 120 * x * (1 - x)) / 40).toFixed(3)})`, ['--bd' as string]: `${0.9 + i * 0.07}s` }}
            />
          ))}
        </div>

        {renderPerson('groom')}

        <div className="cp-amp" aria-hidden="true">
          <svg viewBox="0 0 80 90">
            <text x="40" y="70" textAnchor="middle">&amp;</text>
          </svg>
        </div>

        {renderPerson('bride')}
      </div>

      <CoupleQuiz />

      <div className="cp-vows reveal">
        <blockquote className="vow">
          <span className="vow-label">His vow</span>
          <p>{WEDDING_CONTENT.groomVow}</p>
        </blockquote>
        <blockquote className="vow">
          <span className="vow-label">Her vow</span>
          <p>{WEDDING_CONTENT.brideVow}</p>
        </blockquote>
      </div>
      <NextTeaser label="Next: how a Malayali girl beat the language barrier" targetId="story-filmstrip-section" />
    </section>
  );
};
