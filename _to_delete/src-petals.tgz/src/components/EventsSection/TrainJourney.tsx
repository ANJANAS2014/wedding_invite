import './TrainJourney.css';
import React, { useEffect, useRef, useState } from 'react';
import { WEDDING_SCENE } from '../../data/events';

/**
 * The train from Aluva (near the wedding venue) to MGR Chennai Central (reception).
 * Scroll-linked: it comes from far (top-right) and arrives beside the Chennai board.
 */
export const TrainJourney: React.FC = () => {
  const sceneRef = useRef<HTMLDivElement>(null);
  const trainRef = useRef<HTMLDivElement>(null);
  const [arrived, setArrived] = useState(false);

  useEffect(() => {
    const scene = sceneRef.current;
    const train = trainRef.current;
    if (!scene || !train) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      setArrived(true);
      return;
    }
    let raf = 0;
    const update = () => {
      raf = 0;
      const rect = scene.getBoundingClientRect();
      const vh = window.innerHeight;
      const p = Math.min(1, Math.max(0, (vh * 0.95 - rect.top) / (vh * 0.55)));
      train.style.setProperty('--p', p.toFixed(3));
      setArrived(p > 0.97);
    };
    const onScroll = () => {
      if (!raf) raf = window.requestAnimationFrame(update);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    update();
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
      if (raf) window.cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <section
      className={`tr reveal ${arrived ? 'arrived' : ''}`}
      aria-label="The journey from the wedding in Kerala to the reception in Chennai"
    >
      <div className="tr-head">
        <p className="eyebrow">From the wedding to the reception</p>
        <h3 className="tr-title">All aboard for Chennai</h3>
        <p className="tr-ticket" aria-label="Aluva to Chennai Central">
          <span>AWY</span>
          <i />
          <span>MAS</span>
        </p>
        <p className="tr-dates">
          29 Nov <em>→</em> 6 Dec
        </p>
      </div>

      <div className="tr-scene" ref={sceneRef}>
        <figure className="tr-board tr-from">
          <div className="tr-plate">
            <span lang="ml">ആലുവ</span>
            <span lang="hi">आलुवा</span>
            <b>ALUVA</b>
          </div>
          <figcaption>Wedding · 29 Nov</figcaption>
        </figure>

        <div className="tr-train" ref={trainRef}>
          <div className="tr-rumble">
            <img src={WEDDING_SCENE.train} alt="A train travelling from Aluva to Chennai" width={700} height={473} loading="lazy" decoding="async" />
            <span className="tr-lamp" style={{ left: '37%', top: '5.5%' }} />
            <span className="tr-lamp" style={{ left: '24%', top: '43.5%' }} />
            <span className="tr-lamp" style={{ left: '47.3%', top: '43.5%' }} />
          </div>
        </div>

        <figure className="tr-board tr-to">
          <div className="tr-plate">
            <span lang="ta">சென்னை சென்ட்ரல்</span>
            <span lang="hi">चेन्नई सेंट्रल</span>
            <b>MGR CHENNAI CENTRAL</b>
          </div>
          <figcaption>Reception · 6 Dec</figcaption>
        </figure>
      </div>
    </section>
  );
};
